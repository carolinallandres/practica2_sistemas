//Fichero "hello.c"

void imprimehello(void);

int main(int argc, char* argv[]) {
	imprimehello();
	return 0;
}
