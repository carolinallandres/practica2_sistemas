//Fichero "imprime.c"

#include <stdio.h>

void imprimehello(void) {
	printf("Hello, World!\n");
}
