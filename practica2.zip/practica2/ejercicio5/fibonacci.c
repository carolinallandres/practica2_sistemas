#include <stdio.h>
#include <stdlib.h>

int fibonacci (int n) {
	if (n<=1) {
		return n;
	}

	return fibonacci(n-1) + fibonacci(n-2);
}

int main (int argc, char* argv[]) {
	int numero = atoi(argv[1]);

	printf("%d\n", fibonacci(numero));


	return 0;
}
