#include <stdio.h>
#include <stdlib.h>

int factorial (int n);

int main (int argc, char* argv[]) {
	int numero = atoi (argv[1]);
	
	printf("%d\n", factorial(numero));

	return 0;
}
