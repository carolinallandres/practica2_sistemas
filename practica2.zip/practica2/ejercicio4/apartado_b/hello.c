//Fichero "hello.c"

#include "imprime.h"

int main(int argc, char* argv[]) {
	imprimehello();
	return 1;
}
